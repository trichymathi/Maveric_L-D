package pra.selenium.setup;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SelniumPracticeJava {
	
	public void driverSetup() {
		//String firefoxDriverPath = new File("C:\\Users\\mathimaranr\\eclipse-workspace\\Selenium_New_Project\\driver\\geckodriver.exe").getAbsolutePath();
		//String chromeDriverPath = new File("C:\\Users\\mathimaranr\\eclipse-workspace\\Selenium_New_Project\\driver\\chromedriver.exe").getAbsolutePath();
		//System.setProperty("webdriver.chrome.driver",chromeDriverPath);
		WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-dev-shm-usage");
		options.addArguments("--ignore-ssl-errors=yes");
		options.addArguments("--ignore-certificate-errors'");
		options.addArguments("--disable-dev-shm-usage");
		ChromeDriver driver = new ChromeDriver(options);
		//FirefoxDriver driver = new FirefoxDriver();
		driver.get("https://chromedriver.storage.googleapis.com/index.html?path=114.0.5735.90/");
		
		WebElement findElement = driver.findElement(By.xpath(""));
		
	}

	public static void main(String[] args) {
		SelniumPracticeJava obj = new SelniumPracticeJava();
		obj.driverSetup();

	}

}
