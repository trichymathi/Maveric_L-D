package Activity_01;

import java.util.Scanner;

import com.codoid.products.exception.FilloException;

public class Call_01 extends Student_Information {

	public static void main(String[] args) throws FilloException, InterruptedException {
		Call_01 cl = new Call_01();
		Scanner scn_2 = new Scanner(System.in);

		System.out.println("Menu"+"\n1.Student"+"\n2.Staff"+"\n3.Student Alumini"+"\n4.Staff Alumini"+"\n5.Student staff info");
		System.out.println("Enter the Name Of Menu (Eg:Student)");
		String opt = scn_2.nextLine();
		if(opt.equalsIgnoreCase("Student")) {
			System.out.println("Enter the Option To Work(Add,Delete,Update)");
			String opt_1 = scn_2.next();
			if(opt_1.equalsIgnoreCase("Add")) {
				Scanner sc = new Scanner(System.in);
				cl.Add();
			}
			if(opt_1.equalsIgnoreCase("Delete")) {
				cl.Delete();
			}
		}
		if(opt.equalsIgnoreCase("Staff")) {
			System.out.println("Enter the Option To Work(Add,Delete,Update)");
			String opt_2 = scn_2.nextLine();
			if(opt_2.equalsIgnoreCase("Add")) {
				Scanner sc = new Scanner(System.in);
				cl.Staff_add();
			}
			if(opt_2.equalsIgnoreCase("Delete")) {
				cl.Staff_Delete();
			}
		}
		if(opt.equalsIgnoreCase("Student Alumini")) {
			cl.Student_Alumini();
		}
		if(opt.equalsIgnoreCase("Staff Alumini")) {
			cl.Staff_Alumini();
		}
		if(opt.equalsIgnoreCase("Student staff info")) {
			cl.Student_Staff_info();
		}
	}
}


