package Activity_01;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

	public class Student_Information {
		Scanner scn = new Scanner(System.in);
		String stdName;
		String classes;
		double higt;
		double wgt;
		int Std_id;
		java.util.Date dt = new java.util.Date();
		@SuppressWarnings("deprecation")
		int year = dt.getYear();
		int currentYear = year+1900;
		java.util.Date date=new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String date_01 =formatter.format(date);

		////////////////////////////////////////////////Student Add////////////////////////////////////////////////////////////

		public void Add() throws FilloException {

			System.out.println("How Many Number Of Students To Add");
			int nos = scn.nextInt();
			for(int i=1;i<=nos;i++) {

				Fillo fillo = new Fillo();
				Connection connection = fillo.getConnection("C:\\Users\\mathimaranr\\OneDrive - Maveric Systems Limited\\java program\\Record_06.xlsx");
				Std_id = 100;
				for(int j=1;j<=i;j++) {
					Std_id++;
				}
				System.out.println("STUDENT ID IS:"+Std_id);

				System.out.println("Enter Student name"+(i));
				stdName = scn.next();

				System.out.println("Enter Student class");
				classes = scn.next();

				System.out.println("Enter Student Height");
				higt = scn.nextDouble();

				System.out.println("Enter Student Weight");
				wgt = scn.nextDouble();
				String strQuery = "INSERT INTO Student(Student_ID,Student_Name,Student_Class,Height,Weight) VALUES('"+Std_id+"'"+","+"'"+stdName+"'"+","+"'"+classes+"'"+","+"'"+higt+"'"+","+"'"+wgt+"'"+")";
				connection.executeUpdate(strQuery);
				connection.close();
				/* String strQuery_1="Delete From Student";
	                                    connection.executeUpdate(strQuery_1);*/
			}           
		}

		/////////////////////////////////////////////////////////////Student Delete//////////////////////////////////////////////////////////////////////

		public void Delete() throws FilloException, InterruptedException {
			Fillo fillo = new Fillo();
			Connection connection = fillo.getConnection("C:\\\\Users\\\\mathimaranr\\\\OneDrive - Maveric Systems Limited\\\\java program\\\\Record_06.xlsx");
			System.out.println("Enter Student ID");
			Std_id = scn.nextInt();
			String Query ="Select * From Student Where Student_ID="+"'"+Std_id+"'"+"";
			Recordset rs = connection.executeQuery(Query);

			while(rs.next()) {
				String field = rs.getField("Student_Name");
				String field2 = rs.getField("Student_Class");
				//String field3 = rs.getField("Height");
				//String field4 = rs.getField("Weight");
				System.out.println(field+field2);
				String strQuery_1 = "INSERT INTO Student_Alumini(Student_ID,Student_Name,Student_Class,Year_Of_Student_Leave) VALUES('"+Std_id+"'"+","+"'"+field+"'"+","+"'"+field2+"'"+","+"'"+currentYear+"'"+")";
				connection.executeUpdate(strQuery_1);
			}
			rs.close();
			Thread.sleep(2000); 
			String strQuery = "Delete From Student Where Student_ID ='"+Std_id+"'";
			connection.executeUpdate(strQuery);
			connection.close();
		}

		///////////////////////////////////////////////Student Update///////////////////////////////////////////////////////////////

		public void Update() {
			System.out.println("Enter Student ID");
			Std_id = scn.nextInt();
			System.out.println("Enter Student class");
			classes = scn.next();
		}

		////////////////////////////////////////////////Student Alumini////////////////////////////////////////////////////////////

		public void Student_Alumini() throws FilloException {
			Fillo fillo = new Fillo();
			Connection connection = fillo.getConnection("C:\\Users\\mathimaranr\\OneDrive - Maveric Systems Limited\\java program\\Record_06.xlsx");
			String strQuery = "Select * From Student_Alumini ";
			Recordset rs = connection.executeQuery(strQuery);
			while(rs.next()) {
				System.out.println("Student ID :"+" "+rs.getField("Student_ID")+"||"+"Student Name :"+" "+rs.getField("Student_Name")+"||"+"Student Class :"+" "+rs.getField("Student_Class")+"||"+"Year Of Student Leaved Out :"+rs.getField("Year_Of_Student_Leave"));
			}
			rs.close();
			connection.close();
		}
		/////////////////////////////////////////****************************************************************//////////////////////////////////////////////////


		//////////////////////////////////////////////////////////Staff Add////////////////////////////////////////////////////////

		public void Staff_add() throws FilloException{
			System.out.println("How Many Number Of Staff To Add");
			int nos = scn.nextInt();
			for(int i=1;i<=nos;i++) {

				Fillo fillo = new Fillo();
				Connection connection = fillo.getConnection("C:\\Users\\mathimaranr\\OneDrive - Maveric Systems Limited\\java program\\Record_06.xlsx");
				Std_id = 1000;
				for(int j=1;j<=i;j++) {
					Std_id++;
				}
				System.out.println("STAFF ID IS:"+Std_id);

				System.out.println("Enter Staff name"+(i));
				stdName = scn.next();

				System.out.println("Enter Staff class");
				classes = scn.next();

				String strQuery = "INSERT INTO Staff_Info(Staff_ID,Staff_Name,Staff_Class) VALUES('"+Std_id+"'"+","+"'"+stdName+"'"+","+"'"+classes+"'"+")";
				connection.executeUpdate(strQuery);
				connection.close();
				/* String strQuery_1="Delete From Student";
	                                    connection.executeUpdate(strQuery_1);*/
			}

		}

		//////////////////////////////////////////////////////////////Staff Delete///////////////////////////////////////////////////

		public void Staff_Delete() throws FilloException, InterruptedException{
			Fillo fillo = new Fillo();
			Connection connection = fillo.getConnection("C:\\Users\\mathimaranr\\OneDrive - Maveric Systems Limited\\java program\\Record_06.xlsx");
			System.out.println("Enter Staff ID");
			Std_id = scn.nextInt();
			String Query ="Select * From Staff_Info Where Staff_ID="+"'"+Std_id+"'"+"";
			Recordset rs = connection.executeQuery(Query);

			while(rs.next()) {
				//String field = rs.getField("Staff_ID");
				String field2 = rs.getField("Staff_Name");
				String field3 = rs.getField("Staff_Class");
				//String field4 = rs.getField("Weight");
				System.out.println(field2+field3);
				String strQuery_1 = "INSERT INTO Staff_Alumini(Staff_ID,Staff_Name,Staff_Class,Date_Of_Leaved) VALUES('"+Std_id+"'"+","+"'"+field2+"'"+","+"'"+field3+"'"+","+"'"+date_01+"'"+")";
				connection.executeUpdate(strQuery_1);
			}
			rs.close();
			Thread.sleep(1000); 

			String strQuery = "Delete From Staff_Info Where Staff_ID ='"+Std_id+"'";
			connection.executeUpdate(strQuery);
			connection.close();
		}

		///////////////////////////////////////////////////////////////Staff Alumini///////////////////////////////////////////////////////	

		public void Staff_Alumini() throws FilloException {
			Fillo fillo = new Fillo();
			Connection connection = fillo.getConnection("C:\\Users\\mathimaranr\\OneDrive - Maveric Systems Limited\\java program\\Record_06.xlsx");
			String strQuery = "Select * From Staff_Alumini ";
			Recordset rs = connection.executeQuery(strQuery);
			while(rs.next()) {
				System.out.println("Staff ID :"+" "+rs.getField("Staff_ID")+"||"+"Staff Name :"+" "+rs.getField("Staff_Name")+"||"+"Class :"+" "+rs.getField("Staff_Class")+"||"+"Date of Leaved :"+rs.getField("Date_Of_Leaved"));
			}
			rs.close();
			connection.close();
		}

		///////////////////////////////////////////////////********************************************//////////////////////////////////////////////
		public void Student_Staff_info() throws FilloException {
			Fillo fillo = new Fillo();
			Connection connection = fillo.getConnection("C:\\Users\\mathimaranr\\OneDrive - Maveric Systems Limited\\java program\\Record_06.xlsx");
			Scanner Scn = new Scanner(System.in);
			System.out.println(" Enter the Class Details");
			String classes = Scn.nextLine();
			Recordset rs_1 = connection.executeQuery("Select * From Student").where("Student_Class="+"'"+classes+"'");
			Recordset rs_2 = connection.executeQuery("Select * From Staff_Info").where("Staff_Class="+"'"+classes+"'");
			while(rs_1.next()|rs_2.next()) {
				String field = rs_1.getField("Student_ID");
				String field2 = rs_1.getField("Student_Name");
				String field3 = rs_2.getField("Staff_Class");
				String field4 = rs_2.getField("Staff_Name");
				System.out.println(field+field2+field3+field4);

				String StrQuery ="INSERT INTO Student_Staff_Info(Student_Id,Student_Name,Student_Class,Staff_Name) VALUES('"+field+"'"+","+"'"+field2+"'"+","+"'"+field3+"'"+","+"'"+field4+"'"+")";
				connection.executeUpdate(StrQuery);
			}
			rs_1.close();
			rs_2.close();
			connection.close();
		}
	}

